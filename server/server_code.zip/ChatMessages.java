package com.framelessboard;

import com.google.gson.*;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/chatmessages")
public class ChatMessages {
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMessages(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            String username = DAO.getData(accesstoken);
            if (DAO.ifExist("activeusers").equals("false")) {
                message = "{\"message\":\"Not an active user\"}";
                sresponse = Response.status(403).entity(message).build();
                return sresponse;
            }
            else
            {
                if (DAO.querySet("activeusers", username).equals("false")) {
                    message = "{\"message\":\"Not an active user\"}";
                    sresponse = Response.status(403).entity(message).build();
                    return sresponse;
                }
            }
            String chatmessages = DAO.getData("chatmessages");
            message = "{\"result\": " + chatmessages + ", \"message\":\"Request completed successfully\"}";
            sresponse = Response.status(200).entity(message).build();
        }
        return sresponse;
    }

    @GET
    @Path("{cid}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getChangedCanvas(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken, @DefaultValue("none") @PathParam("cid") String cid) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            String username = DAO.getData(accesstoken);
            if (DAO.ifExist("activeusers").equals("false")) {
                message = "{\"message\":\"Not an active user\"}";
                sresponse = Response.status(403).entity(message).build();
                return sresponse;
            }
            else
            {
                if (DAO.querySet("activeusers", username).equals("false")) {
                    message = "{\"message\":\"Not an active user\"}";
                    sresponse = Response.status(403).entity(message).build();
                    return sresponse;
                }
            }

            String chatmessages = DAO.getData("chatmessages");

            String storejsonString = DAO.getData("chatmessages");
            JsonArray storejsonArray = new JsonArray();
            storejsonArray = new JsonParser().parse(storejsonString).getAsJsonArray();
            int tempnum = Integer.valueOf(cid);
            JsonArray resultjsonArray = new JsonArray();
            for (int i = 0; i < storejsonArray.size(); i++) {
                if (Integer.valueOf(storejsonArray.get(i).getAsJsonObject().get("id").getAsString()) > tempnum)
                {
                    resultjsonArray.add(storejsonArray.get(i).getAsJsonObject());
                }
            }

            message = "{\"result\": " + String.valueOf(resultjsonArray) + ", \"message\":\"Request completed successfully\"}";
            sresponse = Response.status(200).entity(message).build();

        }
        return sresponse;
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response updatechatmessage(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken, String x) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            String username = DAO.getData(accesstoken);
            if (DAO.ifExist("activeusers").equals("false")) {
                message = "{\"message\":\"Not an active user\"}";
                sresponse = Response.status(403).entity(message).build();
                return sresponse;
            }
            else
            {
                if (DAO.querySet("activeusers", username).equals("false")) {
                    message = "{\"message\":\"Not an active user\"}";
                    sresponse = Response.status(403).entity(message).build();
                    return sresponse;
                }
            }
            if (DAO.ifExist("mid").equals("false"))
            {
                message = "{\"message\":\"No Canvas\"}";
                sresponse = Response.status(404).entity(message).build();
            }
            else
            {
                int tmp = Integer.valueOf(DAO.getData("cid"));
                tmp = tmp + 1;
                DAO.setData("cid", String.valueOf(tmp));

                //DAO.setData("canvas", x);

                Gson gson = new Gson();

                String storejsonString = DAO.getData("chatmessages");
                JsonArray storejsonArray = new JsonArray();
                storejsonArray = new JsonParser().parse(storejsonString).getAsJsonArray();

                JsonObject tempJson = new JsonObject();
                tempJson.addProperty("id", tmp);
                tempJson.add("request", new JsonParser().parse(x));
                storejsonArray.add(tempJson);
                DAO.setData("chatmessages", String.valueOf(storejsonArray));

                message = "{\"message\":\"Request completed successfully\"}";
                sresponse = Response.status(200).entity(message).build();
            }
        }
        return sresponse;
    }
}
