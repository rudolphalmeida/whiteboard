package com.framelessboard;

import redis.clients.jedis.*;

import java.util.Set;

public class DAO {

    private static String ADDR = "127.0.0.1";
    private static int PORT = 6379;
    private static String AUTH = "";
    private static int MAX_ACTIVE = 1024;
    private static int MAX_IDLE = 200;
    private static int MAX_WAIT = 10000;
    private static int TIMEOUT = 10000;
    private static boolean TEST_ON_BORROW = true;
    private static JedisPool jedisPool = null;
    public static final int DEFAULT_DATABASE = 0;
    private static Jedis jedis = null;
    private static JedisPool pool = new JedisPool(new JedisPoolConfig(), ADDR);

    public static String getData(String querydata){
        try {
            jedis = pool.getResource();
            String result = jedis.get(querydata);;
            return result;
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }
    public static String setData(String setdata, String datavalue){
        try {
            jedis = pool.getResource();
            String result = jedis.set(setdata, datavalue);;
            return result;
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }

    public static String delData(String deldata){
        try {
            jedis = pool.getResource();
            String result = String.valueOf(jedis.del(deldata));
            return result;
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }

    public static String addSet(String setname, String data){
        try {
            jedis = pool.getResource();
            String result = String.valueOf(jedis.sadd(setname, data));
            return result;
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }

    public static String querySet(String setname, String data){
        try {
            jedis = pool.getResource();
            String result = String.valueOf(jedis.sismember(setname, data));
            return result;
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }

    public static String removefromSet(String setname, String data){
        try {
            jedis = pool.getResource();
            String result = String.valueOf(jedis.srem(setname, data));
            return result;
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }

    public static String ifExist(String data){
        try {
            jedis = pool.getResource();
            String result = String.valueOf(jedis.exists(data));
            return result;
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }

    public static Set getWholeSet(String setname){
        try {
            jedis = pool.getResource();
            Set result = jedis.smembers(setname);
            return result;
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }

    public static String addZset(String setname, long score, String data){
        try {
            jedis = pool.getResource();
            String result = String.valueOf(jedis.zadd(setname, score, data));
            return result;
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }

    public static Set getValidZset(String setname, long score1, long score2){
        try {
            jedis = pool.getResource();
            Set result = jedis.zrangeByScore(setname, score1, score2);
            return result;
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }

    public static String removefromZset(String setname, String data){
        try {
            jedis = pool.getResource();
            String result = String.valueOf(jedis.zrem(setname, data));
            return result;
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }
}