package com.framelessboard;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Iterator;

@Path("/manager")
public class Manager {
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getManager(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            String manager = DAO.getData("manager");
            message = "{\"result\": \"" + manager + "\", \"message\":\"Request completed successfully\"}";
            sresponse = Response.status(200).entity(message).build();
        }
        /*
        Iterator iter = DAO.getWholeSet("exa").iterator();
        while (iter.hasNext()) {
            Object x = iter.next();
            System.out.println(x);
        }
        */
        return sresponse;
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response postManager(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            String username = DAO.getData(accesstoken);
            //String manager = DAO.getData("manager");
            if (DAO.ifExist("manager").equals("false"))
            {
                DAO.setData("manager", username);
                message = "{\"message\":\"Request completed successfully\"}";
                sresponse = Response.status(200).entity(message).build();
            }
            else
            {
                message = "{\"message\":\"Manager already exists\"}";
                sresponse = Response.status(405).entity(message).build();
            }
        }
        return sresponse;
    }

    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    public Response delManager(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken) {
        String username = DAO.getData(accesstoken);
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (username.equals("null"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            //String manager = DAO.getData("manager");
            if (DAO.ifExist("manager").equals("false"))
            {
                message = "{\"message\":\"Manager does not exist\"}";
                sresponse = Response.status(405).entity(message).build();
            }
            else
            {
                if (username.equals(DAO.getData("manager")))
                {
                    DAO.delData("manager");
                    message = "{\"message\":\"Request completed successfully\"}";
                    sresponse = Response.status(200).entity(message).build();
                }
                else
                {
                    message = "{\"message\":\"Only manager can delete manager\"}";
                    sresponse = Response.status(403).entity(message).build();
                }
            }
        }
        return sresponse;
    }
}