package com.framelessboard;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Iterator;

@Path("/activeusers")
public class ActiveUsers {
    @POST
    @Path("{user}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response activateSomeone(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken,  @DefaultValue("none") @PathParam("user") String user) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            String username = DAO.getData(accesstoken);
            if (username.equals(DAO.getData("manager")))
            {
                DAO.addSet("activeusers", user);
                DAO.removefromSet("waitingusers", user);
                DAO.removefromSet("rejectedusers", user);
                DAO.removefromSet("kickedusers", user);
                message = "{\"message\":\"Request completed successfully\"}";
                sresponse = Response.status(200).entity(message).build();
            }
            else
            {
                message = "{\"message\":\"Only manager can activate users\"}";
                sresponse = Response.status(403).entity(message).build();
            }
        }
        return sresponse;
    }

    /*
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response ifSelfActive(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            String username = DAO.getData(accesstoken);
            String result = DAO.querySet("activeusers", username);
            if (result.equals("false"))
            {
                message = "{\"result\": \"no\", \"message\":\"Request completed successfully\"}";
            }
            else
            {
                message = "{\"result\": \"yes\", \"message\":\"Request completed successfully\"}";
            }
            sresponse = Response.status(200).entity(message).build();
        }
        return sresponse;
    }

     */

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllActiveUsers(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            //String result = DAO.querySet("onlineusers", user);
            if (DAO.ifExist("activeusers").equals("false"))
            {
                //do nothing
                message = "{\"result\": \"null\", \"message\":\"No avtive user exists\"}";
                sresponse = Response.status(404).entity(message).build();
            }
            else
            {
                Iterator iter = DAO.getWholeSet("activeusers").iterator();
                String result = "[";
                while (iter.hasNext()) {
                    Object x = iter.next();
                    result = result + "\"" + x + "\"" + ", ";
                    //System.out.println(x);
                }
                result = result.substring(0, result.length() - 2) + "]";
                message = "{\"result\": " + result + ", \"message\":\"Request completed successfully\"}";
                sresponse = Response.status(200).entity(message).build();
            }
            //System.out.println(result);
        }
        return sresponse;
    }

    @DELETE
    @Path("{user}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deactivateSomeone(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken,  @DefaultValue("none") @PathParam("user") String user) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            String username = DAO.getData(accesstoken);
            if (username.equals(DAO.getData("manager")) || username.equals(user))
            {
                DAO.removefromSet("activeusers", user);
                DAO.addSet("kickedusers", user);
                message = "{\"message\":\"Request completed successfully\"}";
                sresponse = Response.status(200).entity(message).build();
            }
            else
            {
                message = "{\"message\":\"Only manager can kick users\"}";
                sresponse = Response.status(403).entity(message).build();
            }
        }
        return sresponse;
    }
}
