package com.framelessboard;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Path("/userstate")
public class UserState {
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserState(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            String username = DAO.getData(accesstoken);
            String result = DAO.querySet("activeusers", username);
            //System.out.println(username);
            //System.out.println(result);
            if (result.equals("true"))
            {
                message = "{\"result\": \"active\", \"message\":\"Request completed successfully\"}";
            }
            else if (DAO.querySet("waitingusers", username).equals("true"))
            {
                message = "{\"result\": \"waiting\", \"message\":\"Request completed successfully\"}";
            }
            else if (DAO.querySet("rejectedusers", username).equals("true"))
            {
                message = "{\"result\": \"rejected\", \"message\":\"Request completed successfully\"}";
            }
            else if (DAO.querySet("kickedusers", username).equals("true"))
            {
                message = "{\"result\": \"kicked\", \"message\":\"Request completed successfully\"}";
            }
            else
            {
                message = "{\"result\": \"null\", \"message\":\"Request completed successfully\"}";
            }
            sresponse = Response.status(200).entity(message).build();
            //System.out.println(result);
        }

        return sresponse;
    }
}
