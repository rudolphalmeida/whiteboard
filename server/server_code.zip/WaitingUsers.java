package com.framelessboard;

import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.util.Iterator;

@Path("/waitingusers")
public class WaitingUsers {
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response selfWaiting(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            String username = DAO.getData(accesstoken);
            DAO.addSet("waitingusers", username);
            message = "{\"message\":\"Request completed successfully\"}";
            sresponse = Response.status(200).entity(message).build();
        }
        return sresponse;
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllWaitingUsers(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            //String result = DAO.querySet("onlineusers", user);
            if (DAO.ifExist("waitingusers").equals("false"))
            {
                //do nothing
                message = "{\"result\": \"null\", \"message\":\"No waiting user exists\"}";
                sresponse = Response.status(404).entity(message).build();
            }
            else
            {
                Iterator iter = DAO.getWholeSet("waitingusers").iterator();
                String result = "[";
                while (iter.hasNext()) {
                    Object x = iter.next();
                    result = result + "\"" + x + "\"" + ", ";
                    //System.out.println(x);
                }
                result = result.substring(0, result.length() - 2) + "]";
                message = "{\"result\": " + result + ", \"message\":\"Request completed successfully\"}";
                sresponse = Response.status(200).entity(message).build();
            }
            //System.out.println(result);
        }
        return sresponse;
    }

    @DELETE
    @Path("{user}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response rejectSomeone(@DefaultValue("none") @HeaderParam("Access-Token") String accesstoken,  @DefaultValue("none") @PathParam("user") String user) {
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (DAO.ifExist(accesstoken).equals("false"))
        {
            message = "{\"message\":\"Not a legal user\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        else
        {
            String username = DAO.getData(accesstoken);
            if (username.equals(DAO.getData("manager")) || username.equals(user))
            {
                DAO.removefromSet("waitingusers", user);
                DAO.addSet("rejectedusers", user);
                message = "{\"message\":\"Request completed successfully\"}";
                sresponse = Response.status(200).entity(message).build();
            }
            else
            {
                message = "{\"message\":\"Only manager can reject users\"}";
                sresponse = Response.status(403).entity(message).build();
            }
        }
        return sresponse;
    }
}
