package com.framelessboard;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/accesstoken")
public class AccessToken {
    @GET
    //@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAccessToken(@DefaultValue("none") @HeaderParam("Code") String code, @DefaultValue("none") @HeaderParam("User") String username) {
        String rightcode = "471e61cd2878317b204b878dfc918d2b";
        String accesstoken = "null";
        String pretoken = "null";
        String message = "{\"message\":\"Successfully Connected\"}";
        Response sresponse = Response.status(200).entity(message).build();
        if (username.equals("null"))
        {
            message = "{\"message\":\"You can not use \"null\" as a user name\"}";
            sresponse = Response.status(401).entity(message).build();
            return sresponse;
        }
        if(rightcode.equals(code))
        {
            //System.out.println(DAO.ifExist(username));
            if (DAO.ifExist(username).equals("true"))
            {
                pretoken = DAO.getData(username);
                DAO.delData(pretoken);
            }
            accesstoken = Hash.doHash(username);
            DAO.setData(username, accesstoken);
            DAO.setData(accesstoken,username);
            message = "{\"message\":\"Successfully obtained accesstoken\"}";
            sresponse = Response.status(200).entity(message).header("Access-Token", accesstoken).build();
        }
        else
        {
            message = "{\"message\":\"Code is not correct\"}";
            sresponse = Response.status(401).entity(message).build();
        }
        //System.out.println(DAO.getData("yyy"));
        return sresponse;
    }
}
